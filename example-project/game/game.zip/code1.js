gdjs.StartCode = {};
gdjs.StartCode.localVariables = [];
gdjs.StartCode.GDNewSpriteObjects1= [];
gdjs.StartCode.GDNewSpriteObjects2= [];
gdjs.StartCode.GDNewSprite2Objects1= [];
gdjs.StartCode.GDNewSprite2Objects2= [];
gdjs.StartCode.GDNewSprite3Objects1= [];
gdjs.StartCode.GDNewSprite3Objects2= [];
gdjs.StartCode.GDNewSprite4Objects1= [];
gdjs.StartCode.GDNewSprite4Objects2= [];
gdjs.StartCode.GDNewSprite5Objects1= [];
gdjs.StartCode.GDNewSprite5Objects2= [];
gdjs.StartCode.GDNewTextObjects1= [];
gdjs.StartCode.GDNewTextObjects2= [];
gdjs.StartCode.GDNewSprite6Objects1= [];
gdjs.StartCode.GDNewSprite6Objects2= [];
gdjs.StartCode.GDNewText2Objects1= [];
gdjs.StartCode.GDNewText2Objects2= [];


gdjs.StartCode.mapOfGDgdjs_9546StartCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.StartCode.GDNewSprite2Objects1});
gdjs.StartCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.StartCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.StartCode.mapOfGDgdjs_9546StartCode_9546GDNewSprite2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "");
}}

}


};

gdjs.StartCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StartCode.GDNewSpriteObjects1.length = 0;
gdjs.StartCode.GDNewSpriteObjects2.length = 0;
gdjs.StartCode.GDNewSprite2Objects1.length = 0;
gdjs.StartCode.GDNewSprite2Objects2.length = 0;
gdjs.StartCode.GDNewSprite3Objects1.length = 0;
gdjs.StartCode.GDNewSprite3Objects2.length = 0;
gdjs.StartCode.GDNewSprite4Objects1.length = 0;
gdjs.StartCode.GDNewSprite4Objects2.length = 0;
gdjs.StartCode.GDNewSprite5Objects1.length = 0;
gdjs.StartCode.GDNewSprite5Objects2.length = 0;
gdjs.StartCode.GDNewTextObjects1.length = 0;
gdjs.StartCode.GDNewTextObjects2.length = 0;
gdjs.StartCode.GDNewSprite6Objects1.length = 0;
gdjs.StartCode.GDNewSprite6Objects2.length = 0;
gdjs.StartCode.GDNewText2Objects1.length = 0;
gdjs.StartCode.GDNewText2Objects2.length = 0;

gdjs.StartCode.eventsList0(runtimeScene);
gdjs.StartCode.GDNewSpriteObjects1.length = 0;
gdjs.StartCode.GDNewSpriteObjects2.length = 0;
gdjs.StartCode.GDNewSprite2Objects1.length = 0;
gdjs.StartCode.GDNewSprite2Objects2.length = 0;
gdjs.StartCode.GDNewSprite3Objects1.length = 0;
gdjs.StartCode.GDNewSprite3Objects2.length = 0;
gdjs.StartCode.GDNewSprite4Objects1.length = 0;
gdjs.StartCode.GDNewSprite4Objects2.length = 0;
gdjs.StartCode.GDNewSprite5Objects1.length = 0;
gdjs.StartCode.GDNewSprite5Objects2.length = 0;
gdjs.StartCode.GDNewTextObjects1.length = 0;
gdjs.StartCode.GDNewTextObjects2.length = 0;
gdjs.StartCode.GDNewSprite6Objects1.length = 0;
gdjs.StartCode.GDNewSprite6Objects2.length = 0;
gdjs.StartCode.GDNewText2Objects1.length = 0;
gdjs.StartCode.GDNewText2Objects2.length = 0;


return;

}

gdjs['StartCode'] = gdjs.StartCode;
